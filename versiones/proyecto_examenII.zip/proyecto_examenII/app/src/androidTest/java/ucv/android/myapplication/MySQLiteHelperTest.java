package ucv.android.myapplication;

import junit.framework.TestCase;

public class MySQLiteHelperTest extends TestCase {

    public void testOnCreate() {
    }
}