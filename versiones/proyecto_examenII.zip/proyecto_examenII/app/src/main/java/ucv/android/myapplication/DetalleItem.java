package ucv.android.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetalleItem extends AppCompatActivity {
    Entidad Item;
    TextView txtCurso;
    ImageView imgFoto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_item);

        Item=(Entidad)getIntent().getSerializableExtra("objetoData");

        txtCurso=(TextView) findViewById(R.id.txtCurso);
        imgFoto=(ImageView) findViewById(R.id.Imagen);

        txtCurso.setText(Item.getTitulo());
        imgFoto.setImageResource(Item.getImgFoto());

    }
}